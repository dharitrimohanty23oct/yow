package com.yow.www.yowapplication.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.yow.www.yowapplication.R;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}
