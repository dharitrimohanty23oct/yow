package com.yow.www.yowapplication.activity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.yow.www.yowapplication.R;

public class UpdateActivity extends AppCompatActivity implements View.OnClickListener {
    private Toolbar toolbar;
    private ImageView img;
    private String namevalue;
    private TextView tvToolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        init();
    }
    private void init(){
        toolbar=(Toolbar)findViewById(R.id.toolbar);
        img=toolbar.findViewById(R.id.img);
        tvToolbar=findViewById(R.id.tvToolbar);
        toolbar.setOnClickListener(this);


        Intent intent=getIntent();
        Bundle  bd=intent.getExtras();
        if(bd!=null){
            namevalue=(String)bd.get("Value");

        }

        if(namevalue.equalsIgnoreCase("Name")){
            tvToolbar.setText("Update Name");
        }else if(namevalue.equalsIgnoreCase("Mobile")){
            tvToolbar.setText("Update Mobile Number");
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.toolbar:
                Intent toolbar=new Intent(UpdateActivity.this,AccountDetailsActivity.class);
                startActivity(toolbar);
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out); // for fwd
                break;
        }
    }
}
