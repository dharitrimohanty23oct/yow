package com.yow.www.yowapplication.activity;

import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.yow.www.yowapplication.R;
import com.yow.www.yowapplication.frgament.AccountFragment;

public class DashBoardActivity extends AppCompatActivity  {
    private Toolbar mToolbar;
    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    LinearLayout mLinear,header,lnHome;
    TextView mTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board1);
        mToolbar = (Toolbar) findViewById(R.id.action_bar);
        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayShowHomeEnabled(true);
        // getSupportActionBar().setLogo(R.mipmap.ic_launcher);
       // getSupportActionBar().setDisplayShowTitleEnabled(false);
        mLinear=(LinearLayout)mToolbar.findViewById(R.id.lnTitle);
        mTextView=(TextView)mToolbar.findViewById(R.id.tvTitle);
        mLinear.setVisibility(View.VISIBLE);
        mTextView.setVisibility(View.GONE);
        navigationView=(NavigationView)findViewById(R.id.navigation_view_left);
        View headerview = navigationView.getHeaderView(0);
        header=(LinearLayout)headerview.findViewById(R.id.drawer_list);
        drawerLayout=(DrawerLayout)findViewById(R.id.drawer);
        lnHome=(LinearLayout)findViewById(R.id.lnHome);
        lnHome.setVisibility(View.VISIBLE);
       // setDrawerLayout(); 
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout,
                mToolbar, R.string.drawer_open, R.string.drawer_close) {

            @Override
            public void onDrawerClosed(View drawerView) {
                // Write code to perform action when drawer is closed.
                super.onDrawerClosed(drawerView);
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                // Write code to perform action when drawer is sliding.
                super.onDrawerSlide(drawerView, slideOffset);
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                // Write code to perform action when drawer is opened.
                super.onDrawerOpened(drawerView);
            }
        };
        actionBarDrawerToggle.getDrawerArrowDrawable().setColor(getResources().getColor(R.color.black));
        // Set the actionbarToggle to drawer layout.
        drawerLayout.addDrawerListener(actionBarDrawerToggle);

        // Calling sync state is necessary or else your hamburger icon wont show up.
        actionBarDrawerToggle.syncState();

        setupDrawerContent(navigationView);

        header.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.closeDrawers(); //close drawer

                AccountFragment selectedFragment = new AccountFragment();
                mLinear.setVisibility(View.GONE);
                mTextView.setVisibility(View.VISIBLE);
                mTextView.setText("Your Account");
                lnHome.setVisibility(View.GONE);
                // selectedFragment.setTitle(String.valueOf(menuItem.getTitle()));
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.frame_layout, selectedFragment);
                fragmentTransaction.commit();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_multi_select, menu);
        return true;
    }
    private void setupDrawerContent(NavigationView navigationView) {
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        // Toggle the checked state of menuItem.
                      //  menuItem.setChecked(!menuItem.isChecked());

                        // Close the drawer
                        drawerLayout.closeDrawers();

                        selectDrawerItem(menuItem);
                        return true;
                    }
                });
    }

    public void selectDrawerItem(MenuItem menuItem) {
   /*     // Create a new fragment and specify the fragment to show based on nav item clicked
        Fragment fragment = null;
        Class fragmentClass=null;
        switch(menuItem.getItemId()) {
            case R.id.rlv_nav:
                fragmentClass =AccountFragment.class;
                break;
          *//*  case R.id.nav_second_fragment:
                fragmentClass = SecondFragment.class;
                break;
            case R.id.nav_third_fragment:
                fragmentClass = ThirdFragment.class;
                break;
            default:
                fragmentClass = FirstFragment.class;*//*
        }

        try {
            fragment = (Fragment) fragmentClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Insert the fragment by replacing any existing fragment
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.flContent, fragment).commit();

        // Highlight the selected item has been done by NavigationView
        menuItem.setChecked(true);
        // Set action bar title
        setTitle(menuItem.getTitle());
        // Close the navigation drawer
        mDrawer.closeDrawers();*/
        switch (menuItem.getItemId()) {

          /*  case R.id.rlv_nav:
                AccountFragment selectedFragment = new AccountFragment();
                mLinear.setVisibility(View.GONE);
                mTextView.setVisibility(View.VISIBLE);
                mTextView.setText("Your Account");
               // selectedFragment.setTitle(String.valueOf(menuItem.getTitle()));
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.frame_layout, selectedFragment);
                fragmentTransaction.commit();
                break;*/
        }




    }



}
